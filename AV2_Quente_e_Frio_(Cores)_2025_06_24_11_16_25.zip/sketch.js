  let x ;
  let y ;

  function setup(){
  createCanvas(500, 400);
  x = random(400);
  x = int(x);
  y = random(400);
  y = int(y);
}

  function draw() {
  background("lightblue");
  x = x + random (-5, 5);
  y = y + random (-5, 5);
  x = constrain(x, 1, 400);
  y = constrain(x, 1, 400);
  let distancia
  distancia = dist (mouseX, mouseY, x, y);
  circle (mouseX,mouseY, distancia);
  //circle (x, y, 10);
    
  if (distancia < 20) {
  text("Encontrei!", 200, 200);
  noLoop();
  }
}
  